package com.metro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineMetroTicketBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
