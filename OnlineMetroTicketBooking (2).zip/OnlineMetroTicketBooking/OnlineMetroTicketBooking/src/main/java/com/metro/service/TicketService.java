package com.metro.service;

import org.springframework.stereotype.Service;

import com.metro.component.Ticket;

@Service
public interface TicketService {
	Ticket bookTicket(String sourceStation, String destinationStation);

	boolean validateTicket(Long ticketId, String station);

	Ticket generateTicket(String sourceStation, String destinationStation);
	
}
