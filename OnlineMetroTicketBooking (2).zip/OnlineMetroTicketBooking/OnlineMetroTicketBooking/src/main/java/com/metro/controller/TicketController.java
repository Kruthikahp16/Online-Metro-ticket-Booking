package com.metro.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.metro.component.Ticket;
import com.metro.dto.TicketRequest;
import com.metro.dto.TicketValidationRequest;
import com.metro.service.TicketService;

@RestController
public class TicketController {
	@Autowired
	private TicketService ticketService;

	@PostMapping("/book-ticket")
	public Ticket bookTicket(@RequestBody TicketRequest ticketRequest) {
		return ticketService.bookTicket(ticketRequest.getSourceStation(), ticketRequest.getDestinationStation());
	}

	@PostMapping("/validate-ticket")
	public String validateTicket(@RequestBody TicketValidationRequest validationRequest) {
		boolean isValid = ticketService.validateTicket(validationRequest.getTicketId(), validationRequest.getStation());
		return isValid ? "Valid Ticket" : "Invalid Ticket";
	}
}