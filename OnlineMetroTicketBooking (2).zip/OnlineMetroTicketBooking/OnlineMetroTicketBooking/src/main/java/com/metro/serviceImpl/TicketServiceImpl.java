package com.metro.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.metro.component.Ticket;
import com.metro.repository.TicketRepository;
import com.metro.service.TicketService;
import java.time.LocalDateTime;

@Service
public class TicketServiceImpl implements TicketService {

	@Autowired
	private TicketRepository ticketRepository;

	@Override
	public Ticket bookTicket(String sourceStation, String destinationStation) {
		Ticket ticket = new Ticket();
		ticket.setSourceStation(sourceStation);
		ticket.setDestinationStation(destinationStation);
		ticket.setExpiryTime(LocalDateTime.now().plusHours(18));
		ticket.setRemainingUses(2);
		return ticketRepository.save(ticket);
	}

	@Override
	public boolean validateTicket(Long ticketId, String station) {
		Ticket ticket = ticketRepository.findById(ticketId).orElse(null);
		if (ticket == null || ticket.getExpiryTime().isBefore(LocalDateTime.now()) || ticket.getRemainingUses() <= 0) {
			return false;
		}

		if (station.equals(ticket.getSourceStation()) || station.equals(ticket.getDestinationStation())) {
			ticket.setRemainingUses(ticket.getRemainingUses() - 1);
			ticketRepository.save(ticket);
			return true;
		}
		return false;
	}

	@Override
	public Ticket generateTicket(String sourceStation, String destinationStation) {
		Ticket ticket = new Ticket();
		ticket.setSourceStation(sourceStation);
		ticket.setDestinationStation(destinationStation);
		ticket.setExpiryTime(LocalDateTime.now().plusHours(18));
		ticket.setRemainingUses(2);
		return ticketRepository.save(ticket);
	}
}
