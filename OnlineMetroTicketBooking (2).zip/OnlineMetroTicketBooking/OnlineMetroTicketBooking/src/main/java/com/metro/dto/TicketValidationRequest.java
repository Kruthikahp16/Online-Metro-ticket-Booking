package com.metro.dto;

public class TicketValidationRequest {
	private Long ticketId;
	private String station;
	private boolean enteringStation;

	public Long getTicketId() {
		return ticketId;
	}

	public void setTicketId(Long ticketId) {
		this.ticketId = ticketId;
	}

	public String getStation() {
		return station;
	}

	public void setStation(String station) {
		this.station = station;
	}

	public boolean isEnteringStation() {
		return enteringStation;
	}

	public void setEnteringStation(boolean enteringStation) {
		this.enteringStation = enteringStation;
	}

}
